import prompt

def welcome_user():
	user_name = prompt.string('Dear friend! What is your name?  ')
	print(f"Lets's go, {user_name}!")
