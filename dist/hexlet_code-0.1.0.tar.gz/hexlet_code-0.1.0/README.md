### Hexlet tests and linter status:
[![Actions Status](https://github.com/Homedog1983/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Homedog1983/python-project-49/actions)